package com.project.lms.service;

import java.util.List;

import com.project.lms.hibernate.pojo.Book;



public interface BookService {
	public Book bookListing(Book e);
	public List<Book> getBookByProp(String[] prop);
	

}
