package com.project.lms.controller;

import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.lms.hibernate.pojo.Book;
import com.project.lms.hibernate.pojo.UserAuth;
import com.project.lms.service.UserService;

@CrossOrigin(origins = "*", allowedHeaders = "*")//cors filter configuration
@RestController
public class UserController {
	
	
	@Autowired
	private UserService userService;
	@PostMapping("/register")
	public ResponseEntity<?>register(@RequestBody UserAuth e) {
		HttpStatus httpStatus=null;
		UserAuth em=null;
		try{
			String encodedString = Base64.getEncoder().encodeToString(e.getPassword().getBytes());
			e.setPassword(encodedString);
			e.setUserid((e.getEmail()+e.getPassword()));
			e.setId((e.getEmail()+e.getPassword()));
			 Integer i=userService.register(e);
			 if(i==1) {
				em= userService.getUser(e);
			 }
			httpStatus=HttpStatus.CREATED;
		}catch(Exception ex) {
			httpStatus=HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<UserAuth>(em,httpStatus);
	}
	
	/*@PostMapping("/passwordRecovery")
	public ResponseEntity<?>passwordRecovery(@RequestBody Book e) {
		HttpStatus httpStatus=null;
		Book em=null;
		//try{
			 em=bookService.bookListing(e);
			httpStatus=HttpStatus.CREATED;
		}catch(Exception ex) {
			httpStatus=HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Book>(em,httpStatus);
	}*/

	@PostMapping("/login")
	public ResponseEntity<?>login(@RequestBody UserAuth e) {
		HttpStatus httpStatus=null;
		UserAuth em=null;
		try{
			
			 em=userService.getUser(e);
			 if(em!=null) {
				 httpStatus=HttpStatus.OK;
			 }else {
				 httpStatus=HttpStatus.INTERNAL_SERVER_ERROR;
			 }
		}catch(Exception ex) {
			httpStatus=HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<UserAuth>(em,httpStatus);
	}
}
