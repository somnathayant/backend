package com.project.lms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.project.lms.hibernate.pojo.Request;
import com.project.lms.hibernate.pojo.UserAuth;
import com.project.lms.repository.ExchangeRepository;
import com.project.lms.repository.UserAuthRepository;
import com.project.lms.service.ExchangeService;

@Service
public class ExchangeServiceImpl implements ExchangeService{
	
	@Autowired
	private ExchangeRepository exchangeRepository;
	
	 @Autowired
	 private JdbcTemplate exchangeRepo;

	@Override
	public Request exchangeEntry(Request req) {
		// TODO Auto-generated method stub
		return exchangeRepository.save(req);
	}

	@Override
	public List<Request> getAll(String id) {
		// TODO Auto-generated method stub
		List<Request>reqList=new ArrayList<Request>();
		List<Request>resList=new ArrayList<Request>();
		reqList= exchangeRepository.findAll();
		for(Request u:reqList) {
			if(u.getParty1().equalsIgnoreCase(id)) {
				resList.add(u);
			}
		}
		return resList;
	}
	}


