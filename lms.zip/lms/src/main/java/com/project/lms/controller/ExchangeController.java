package com.project.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.lms.hibernate.pojo.Book;
import com.project.lms.hibernate.pojo.Request;
import com.project.lms.service.BookService;
import com.project.lms.service.ExchangeService;

@CrossOrigin(origins = "*", allowedHeaders = "*")//cors filter configuration
@RestController
public class ExchangeController {
	@Autowired
	private ExchangeService exchangeService;
	
	@PostMapping("/exchangeEntry")
	public ResponseEntity<?>exchangeEntry(@RequestBody Request req) {
		HttpStatus httpStatus=null;
		Request em=null;
		try{
			 em=exchangeService.exchangeEntry(req);
			httpStatus=HttpStatus.CREATED;
		}catch(Exception ex) {
			httpStatus=HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Request>(em,httpStatus);
	}
	
	@GetMapping("/getAll/{id}")
	public ResponseEntity<?> getAll(@PathVariable String id){
		HttpStatus httpStatus = null;
		List<Request> e=null;
		try {
			 e=exchangeService.getAll(id);
			httpStatus=HttpStatus.OK;

		}catch(Exception ex) {
			httpStatus=HttpStatus.EXPECTATION_FAILED;
			return new ResponseEntity<String>("No Book Found",httpStatus);

		}
	    	return new ResponseEntity<List<Request>>(e,HttpStatus.OK);
	}
	
}
