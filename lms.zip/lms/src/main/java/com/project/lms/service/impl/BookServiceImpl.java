package com.project.lms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.lms.hibernate.pojo.Book;
import com.project.lms.repository.BookRepository;
import com.project.lms.service.BookService;

@Service
public class BookServiceImpl implements BookService{

	@Autowired
	private BookRepository bookRepo;
	@Override
	public Book bookListing(Book e) {
		// TODO Auto-generated method stub
		return bookRepo.save(e);
	}
	@Override
	public List<Book> getBookByProp(String[] prop) {
		// TODO Auto-generated method stub
		List<Book>bkList=new ArrayList<Book>();
		List<Book>bkListRes=new ArrayList<Book>();
		bkList= bookRepo.findAll();
		Book b1=null;
		for(Book b:bkList) {
			if(prop[1].equalsIgnoreCase("title")) {
				 b1=b.getTitle().equalsIgnoreCase(prop[0])?b:null;
			}if(prop[1].equalsIgnoreCase("author")) {
				 b1=b.getBookauthor().equalsIgnoreCase(prop[0])?b:null;
			}if(prop[1].equalsIgnoreCase("genre")) {
				 b1=b.getGenre().equalsIgnoreCase(prop[0])?b:null;
			}if(prop[1].equalsIgnoreCase("location")) {
				 b1=b.getLoc().equalsIgnoreCase(prop[0])?b:null;
			}
			bkListRes.add(b1);
		}
		return bkListRes;
	}

	

}
