package com.project.lms.service;

import com.project.lms.hibernate.pojo.UserAuth;


public interface UserService {

	public Integer register(UserAuth user);
	public UserAuth passwordRecovery(UserAuth user);
	public UserAuth getUser(UserAuth user);
	
}
