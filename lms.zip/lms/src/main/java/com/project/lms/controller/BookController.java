package com.project.lms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.lms.hibernate.pojo.Book;
import com.project.lms.service.BookService;



@CrossOrigin(origins = "*", allowedHeaders = "*")//cors filter configuration
@RestController
public class BookController {

	
	@Autowired
	private BookService bookService;
	
	@PostMapping("/bookListing")
	public ResponseEntity<?>bookListing(@RequestBody Book e) {
		HttpStatus httpStatus=null;
		Book em=null;
		try{
			 em=bookService.bookListing(e);
			httpStatus=HttpStatus.CREATED;
		}catch(Exception ex) {
			httpStatus=HttpStatus.INTERNAL_SERVER_ERROR;
		}
		return new ResponseEntity<Book>(em,httpStatus);
	}
	
	@GetMapping("/getBook/{prop}")
	public ResponseEntity<?> getBookByProp(@PathVariable String prop){
		HttpStatus httpStatus = null;
		List<Book> e=null;
		String[]para=prop.split("-");
		try {
			 e=bookService.getBookByProp(para);
			httpStatus=HttpStatus.OK;

		}catch(Exception ex) {
			httpStatus=HttpStatus.EXPECTATION_FAILED;
			return new ResponseEntity<String>("No Book Found",httpStatus);

		}
	    	return new ResponseEntity<List<Book>>(e,HttpStatus.OK);
	}
	
}

