package com.project.lms.service;

import java.util.List;

import com.project.lms.hibernate.pojo.Request;



public interface ExchangeService {
	
	public Request exchangeEntry(Request req);
	public List<Request> getAll(String id);
	

}
