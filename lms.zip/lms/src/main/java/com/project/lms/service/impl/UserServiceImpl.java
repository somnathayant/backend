package com.project.lms.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.project.lms.hibernate.pojo.Book;
import com.project.lms.hibernate.pojo.UserAuth;
import com.project.lms.repository.UserAuthRepository;
import com.project.lms.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserAuthRepository userAuthRepo;
	
	 @Autowired
	 private JdbcTemplate userAuthRepoJdbc;
	
	@Override
	public Integer register(UserAuth user) {
		// TODO Auto-generated method stub
		 return userAuthRepoJdbc.update("insert into user_auth (id, userid,email,password) values(?,?,?,?)",
				 user.getId(),user.getUserid(),user.getEmail(),user.getPassword());
		 
	}

	@Override
	public UserAuth passwordRecovery(UserAuth user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserAuth getUser(UserAuth user) {
		// TODO Auto-generated method stub
		List<UserAuth>usrList=new ArrayList<UserAuth>();
		usrList= userAuthRepo.findAll();
		for(UserAuth u:usrList) {
			if(u.getEmail().equalsIgnoreCase(user.getEmail())) {
				if(u.getPassword().equalsIgnoreCase(user.getPassword())) {
					return u;
				}
			}
		}
		return null;
	}

}
